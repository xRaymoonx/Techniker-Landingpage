
# Techniker-Dashboard 🚧📬

[![Node.js](https://img.shields.io/badge/Node.js-18.x-green.svg)](https://nodejs.org)
[![Dockerized](https://img.shields.io/badge/docker-ready-blue.svg)](https://www.docker.com/)
[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](https://opensource.org/licenses/MIT)

Ein automatisiertes Techniker-CRM & Mail-System mit Öffnungstracking, Lead-Scoring & GUI.

---

## 🔧 Features

- ✅ CSV-Kontaktverwaltung
- 📬 E-Mail-Versand via SendGrid
- 👁 Öffnungstracking mit Pixel
- 📨 Follow-Up nur bei geöffneten Mails
- 📊 Scoring nach Aktivität
- ⏰ Erinnerung nach 3 Tagen
- 🖥 Dashboard UI (HTML/CSS/JS)
- 🐳 Docker-fähig & Deploybar via Render

---

## 📦 Installation (lokal)

```bash
git clone https://github.com/deinname/techniker-dashboard.git
cd techniker-dashboard
npm install
cp .env.example .env
node app.js
```

🧠 Trage `SENDGRID_API_KEY` + `ADMIN_EMAIL` in `.env` ein.

---

## 🐳 Docker Deployment

```bash
docker-compose up --build
```

Öffne [http://localhost:3000/dashboard.html](http://localhost:3000/dashboard.html)

---

## 🧪 Reminder CLI

```bash
node send_reminder.js
```

Oder über Dashboard: POST `/remind`

---

## 📂 Struktur

```
app.js                  # Server & Logik
dashboard.html          # Web-Oberfläche
tracker.png             # Öffnungstracking
contacts.csv            # CSV mit Status
send_reminder.js        # CLI-Reminder
Techniker_Dashboard_Pitch.pdf
Render_Deployment_Anleitung.pdf
Dockerfile + docker-compose.yml
```

---

## 🧑‍💼 Kontakt

📧 info@techniker-dashboard.de  
🌐 https://deine-demo.netlify.app

---

MIT License
